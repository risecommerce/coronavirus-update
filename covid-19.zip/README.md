# coronavirus-update


Campaign to raise public awareness about the importance of questions and answers about coronavirus disease (COVID-19).

== Featured ==

* It allows showing a banner to take you to a link where it shows you all the information about COVID-19

**Privacy**

This plugin does not collect or store any user data.

== Installation ==

### INSTALL "COVID-19" FROM WITHIN WORDPRESS

1. Visit the plugins page within your dashboard and select ‘Add New’;
1. Search for ‘COVID-19’;
1. Activate COVID-19 from your Plugins page;

### INSTALL "COVID-19" MANUALLY

1. Upload the ‘covid-19’ folder to the /wp-content/plugins/ directory;
1. Activate the "COVID-19" plugin through the ‘Plugins’ menu in WordPress;

== Upgrade ==

Just click “Update” on the plugins page and let WordPress do it for you automatically.

== Screenshots ==

1. Version Desktop.
2. Version Mobile.
